package Run;

import org.testng.annotations.Test;

import Base.ClaseBase;
import Base.PagObject;
import Base.PagObjectMeli;

import org.testng.annotations.BeforeClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class RunPruebas {
  PagObject pagina;
  PagObjectMeli paginameli;
  Properties propiedades;
  public WebDriver driver;
  @BeforeClass
  public void beforeClass() throws IOException{
	  propiedades = new Properties();
	  InputStream entradas = null;
	  try {
		  entradas = new FileInputStream("./src/test/resources/Files/recursos");
		 propiedades.load(entradas);
	  } catch(FileNotFoundException e) {
		  e.getStackTrace();
		  System.out.println(e);
	  }
	  pagina = new PagObject(driver);
	  paginameli= new PagObjectMeli(driver);
	  driver = ClaseBase.ChromeConnection();
	  pagina.ObtenerURL(propiedades.getProperty("url"));
  }
  @Test
  public void BusquedaMeli() throws InterruptedException{
	  pagina.BusquedaMeli();
	 /* pagina.IngresoMeli(); */
  }
  @Test
  public void InicioMeli() throws InterruptedException{
	  paginameli.IngresoMeli();
  }

  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
