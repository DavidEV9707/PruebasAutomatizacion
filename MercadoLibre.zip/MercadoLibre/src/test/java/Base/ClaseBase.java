package Base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;

public class ClaseBase {
public ClaseBase(WebDriver driver) {
	super();
}
protected static WebDriver driver;

public static WebDriver ChromeConnection() {
	ChromeOptions chromeoptions= new ChromeOptions();
	chromeoptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
	System.getProperty("webdriver.chrome.driver", "./src/test/resources/driver/chromedriver.exe");
	driver= new ChromeDriver();
	driver.manage().window().maximize();
	return driver;
}
public void TiempoEsperado(long tiempo) throws InterruptedException{
	Thread.sleep(tiempo);
}
public void Click(By locator) throws InterruptedException{
	driver.findElement(locator).click();
	TiempoEsperado(2500);
}
public void Escribir(By locator, String palabra) throws InterruptedException{
	driver.findElement(locator).sendKeys(palabra);
	TiempoEsperado(2000);
}
public void Enter(By locator) throws InterruptedException{
	driver.findElement(locator).submit();
	TiempoEsperado(2000);
}
public boolean ImagenDesplegada(By locator) {
	try {
		return driver.findElement(locator).isDisplayed();
	}catch(NoSuchElementException e) {
		return false;
	}
}
public boolean Clickearboton(By locator) {
	try {
		return driver.findElement(locator).isEnabled();
	}catch(NoSuchElementException e) {
		return false;
	}
}
public boolean AsercionTexto(String texto, By locator) {
	try {
		Assert.assertEquals(texto, driver.findElement(locator).getText());
	} catch(NoSuchElementException e) {
	System.out.println("No se pudo realizar la validación");
	}
	return false;
}


public String ObtenerTexto(By locator) throws InterruptedException{
	return driver.findElement(locator).getText();
}
public void ScrollDown() {
    JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("window.scrollBy(0,450)", "");
}
@SuppressWarnings("deprecation")
public void TiempoEsperaImplicito() {
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

}
