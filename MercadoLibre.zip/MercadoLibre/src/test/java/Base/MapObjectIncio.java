package Base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MapObjectIncio extends ClaseBase{
public MapObjectIncio(WebDriver driver) {
	super(driver);
}
protected By btncrearcuenta= By.xpath("//span[contains(text(),'Crear cuenta')]");
protected By btncuentapersonal= By.xpath("//span[contains(text(),'Crear cuenta personal')]");
protected By lblcuenta= By.xpath("//span[contains(text(),'Solo te tomará unos minutos.')]"); 
protected By firstbutton= By.xpath("//button[@id=\"hub-item-button\"]");
protected By btnagregar= By.xpath("//span[contains(text(),'Agregar')]");
protected By lblemail= By.id("enter-email-input");
protected By checkautorizacion= By.id("policies");
/*protected By btnemail= By.xpath("//ul/li[@id=\"email-without-android-listbox-option-0\"]");*/
protected By btncontinue= By.xpath("//span[contains(text(),'Continuar')]");

protected String textoseteado= "Solo te tomará unos minutos."; 
}
