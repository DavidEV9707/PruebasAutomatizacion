package Base;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;


public class PagObjectMeli extends MapObjectIncio{
	public PagObjectMeli(WebDriver driver) {
		super(driver);
	}
	public void IngresoMeli() throws InterruptedException{
		Click(btncrearcuenta);
	try {
		if(Clickearboton(btncuentapersonal)) {
		TiempoEsperaImplicito();
		AsercionTexto(textoseteado,lblcuenta);
		Click(btncuentapersonal);
		TiempoEsperaImplicito();
		Click(firstbutton);
		TiempoEsperaImplicito();
		Click(checkautorizacion);
		TiempoEsperaImplicito();
		Escribir(lblemail,"Pepitoperez12345@gmail.com");
		TiempoEsperaImplicito();
		Click(btncontinue);
		}else {
		TiempoEsperaImplicito();
		Click(firstbutton);	
		TiempoEsperaImplicito();
		Click(checkautorizacion);
		TiempoEsperaImplicito();
		Escribir(lblemail,"Pepitoperez12345@gmail.com");
		TiempoEsperaImplicito();
		Click(btncontinue);
	}

}
	catch (NoSuchElementException e) {
		System.out.println("No se encontró elemento, termina la automatización");
	}
}
}