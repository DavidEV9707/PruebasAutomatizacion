package Base;

import org.openqa.selenium.WebDriver;
/*import org.testng.Assert;*/

public class PagObject extends MapObject{
	public PagObject(WebDriver driver) {
		super(driver);
	}
	public void ObtenerURL(String URL) {
		driver.get(URL);
	}
	
	public void BusquedaMeli() throws InterruptedException{
		if(ImagenDesplegada(LogoMeli)) {
			Click(btncol);
			Click(aceptarcookies);
			Click(btnlocalizacion);
			Escribir(lblproductos,"Camiseta ac milan");
			Enter(lblproductos);
			Click(acmilan);
			Click(btntalla);
			ScrollDown();
			Click(btncompra);
		}
	}
	
/*public void IngresoMeli() throws InterruptedException{
	Click(btncrearcuenta);
	Assert.assertEquals(ObtenerTexto(lblcuenta), textoseteado);
	Click(firstbutton);
	Click(btnagregar);
	Click(checkautorizacion);
	Escribir(lblemail,"Pepitoperez12345@gmail.com");
	Click(btnemail);
	Click(btncontinue);
}
*/
}
