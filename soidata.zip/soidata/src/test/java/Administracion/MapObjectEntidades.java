package Administracion;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectEntidades extends ClaseBase{
	public MapObjectEntidades(WebDriver driver) {
		super(driver);
	}

	protected By btnadmon= By.xpath("//a[contains(text(),'Administración')]");
	protected By btnentidades= By.xpath("//ul/li/a[contains(text(),'Entidades')]");
	protected By btnnuevaentidad= By.xpath("//button[@ui-sref=\"layout.admin.entidadForm({ id: null })\"]");
	protected By txtentidades= By.xpath("//h2[contains(text(),'ENTIDADES')]");
	protected By lblnombreentidad= By.xpath("//input[@name=\"Nombre entidad\"]");
	protected By lblcodigoentidad= By.xpath("//input[@name=\"código entidad\"]");
	protected By lblcodigoach= By.xpath("//input[@name=\"Codigo ach\"]");
	protected By lblnitentidad= By.xpath("//input[@name=\"NIT Entidad\"]");
	protected By lbldigitoverificacion= By.xpath("//input[@name=\"dígito de verificación\"]");
	protected By listdepartamento= By.xpath("//select[@id=\"departamento\"]");
	protected By listciudad= By.xpath("//select[@id=\"ciudad\"]");
	protected By lbldireccion= By.xpath("//input[@id=\"direccionEntidad\"]");
	protected By lblnombrecontacto= By.xpath("//input[@id=\"nombreContacto\"]");
	protected By lblcorreocontacto= By.xpath("//input[@id=\"correoContacto\"]");
	protected By lbltelefono= By.xpath("//input[@id=\"telefonoContacto\"]");
	protected By listestado= By.xpath("//select[@id=\"estado\"]");
	protected By lbldominio= By.xpath("//input[@id=\"dominioCorreo\"]");
	protected By btnagregardominio= By.xpath("//span[@id=\"basic-addon2\"]");
	protected By lblcodigoarea= By.xpath("//input[@name=\"codeArea\"]");
	protected By lblnombrearea= By.xpath("//input[@name=\"Nombre área o descripción\"]");
	protected By btnagregararea= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[5]/div[3]/div[1]/div[1]/span[1]/div[1]/a[1]/i[1]");
	protected By btnguardarentidad= By.xpath("//button[contains(text(),'Guardar')]");
	
	protected String tituloseteado= "ENTIDADES";
	
}
