package Administracion;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.openqa.selenium.support.ui.Select;

public class PagObjectEntidades extends MapObjectEntidades{

	public PagObjectEntidades(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
public void CrearEntidad() throws InterruptedException {
	Click(btnadmon);
	Click(btnentidades);
	Click(btnnuevaentidad);
	Assert.assertEquals(tituloseteado, textoesperado(txtentidades));
	ScrollDown();
	EnviarParametros(lblnombreentidad,"Entidad de prueba");
	EnviarParametros(lblcodigoentidad,"acs");
	EnviarParametros(lblcodigoach,"77");
	EnviarParametros(lblnitentidad,"45678");
	EnviarParametros(lbldigitoverificacion,"1");
	ListaDepartamentos();
	ListaCiudades();
	EnviarParametros(lbldireccion,"Carretas 85");
	EnviarParametros(lblnombrecontacto,"Pepito Perez");
	EnviarParametros(lbltelefono,"32333456");
	ListaEstado();
	EnviarParametros(lblcorreocontacto,"correoprueba123@psgmail.com");
	EnviarParametros(lbldominio,"psgmail.com");
	Click(btnagregardominio);
	EnviarParametros(lblcodigoarea,"22");
	EnviarParametros(lblnombrearea,"CodigoQA");
	Click(btnagregararea);
	Click(btnguardarentidad);	
}
 public void ListaDepartamentos() {
		Select selectdepartamento= new Select(ListaElementos(listdepartamento));
		selectdepartamento.selectByValue("35");
 }
 public void ListaCiudades() {
		Select selectciudad= new Select(ListaElementos(listciudad));
		selectciudad.selectByValue("5001");
 }
 public void ListaEstado() {
		Select selectestado= new Select (ListaElementos(listestado));
		selectestado.selectByValue("activo");
 }
}
