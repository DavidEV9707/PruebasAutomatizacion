package Run;

import org.testng.annotations.Test;

import Base.ClaseBase;
import Base.PagObject;
import ConsultaConsolidadaJuridica.PagObjectConsultaConsolidadaJuridica;
import ConsultaConsolidadaNatural.PagObjectConsultaDetallada;
import ConsultaIndividual.PagObjectConsulta;
import ConsultaMasiva.PabObjectMasiva;
import Estadistica.PagObjectEstadistica;
import IncluirExcluir.PagObjectIncluirExcluir;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;


public class RunPruebas {
	PagObject pagina;
	PagObjectConsulta paginaconsulta;
	PabObjectMasiva paginaconsultamasiva;
	PagObjectIncluirExcluir incluirexcluir;
	PagObjectEstadistica estadistica;
	PagObjectConsultaDetallada consultadetallada;
	PagObjectConsultaConsolidadaJuridica consultajuridica;
	public WebDriver driver;
	  @BeforeClass
	  public void beforeClass() {
		  pagina = new PagObject(driver);
		  incluirexcluir= new PagObjectIncluirExcluir(driver);
		  paginaconsulta= new PagObjectConsulta(driver);
		  paginaconsultamasiva = new PabObjectMasiva(driver);
		  consultadetallada= new PagObjectConsultaDetallada(driver);
		  estadistica= new PagObjectEstadistica(driver);
		  consultajuridica= new PagObjectConsultaConsolidadaJuridica (driver);
		  driver = ClaseBase.ChromeConnection();
		  pagina.urlSOIDATA("https://testsoidata.com.co/login");
		  
	  }

  @Test
  public void InicioSesion() throws InterruptedException {
	  pagina.InicioSesion();
	  paginaconsulta.ConsultaIndividual();
	 /* incluirexcluir.IncluirExcluirIndividual();
	  paginaconsulta.ConsultaIndividual();
	  paginaconsultamasiva.CargueMasivoConsulta();
	  consultadetallada.ConsultaConsolidada();
	  consultajuridica.ConsultaIndividualMasivaJuridica();*/
	  estadistica.DescargaEntidades();
  }
/* @Test
  public void IncluirExcluir() throws InterruptedException{
	  incluirexcluir.IncluirExcluirIndividual();
	  
  }
  */


  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
