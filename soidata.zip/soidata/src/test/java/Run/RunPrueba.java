package Run;

import org.testng.annotations.Test;

import Base.ClaseBase;
import Base.PagObject;
import ConsultaConsolidadaJuridica.PagObjectConsultaConsolidadaJuridica;
import ConsultaConsolidadaNatural.PagObjectConsultaDetallada;
import ConsultaIndividual.PagObjectConsulta;
import ConsultaMasiva.PabObjectMasiva;
import Estadistica.PagObjectEstadistica;
import IncluirExcluir.PagObjectIncluirExcluir;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;

public class RunPrueba {
	public WebDriver driver;
	Properties propiedades;
	PagObject pagina;
	PagObjectConsultaConsolidadaJuridica consultajuridica;
	PagObjectConsultaDetallada consultadetallada;
	PagObjectConsulta consultaindividual;
	PabObjectMasiva consultamasiva;
	PagObjectEstadistica estadistica;
	PagObjectIncluirExcluir incluirexcluir;
 @BeforeTest
 public void beforeTest() throws InterruptedException, IOException{
	 propiedades = new Properties();
	 InputStream entradas = null;
	  try {
			 entradas = new FileInputStream("./src/test/resources/Files/recursos");
			 propiedades.load(entradas);
		  } catch(FileNotFoundException e) {
			  e.getStackTrace();
			  System.out.println(e);
		  }
	 pagina = new PagObject(driver);
	 consultajuridica= new PagObjectConsultaConsolidadaJuridica(driver);
	 consultadetallada = new PagObjectConsultaDetallada(driver);
	 consultaindividual = new PagObjectConsulta(driver);
	 consultamasiva= new PabObjectMasiva(driver);
	 estadistica = new PagObjectEstadistica(driver);
	 incluirexcluir= new PagObjectIncluirExcluir(driver);
	 driver = ClaseBase.ChromeConnection();
	 pagina.urlSOIDATA(propiedades.getProperty("url"));
	  }
  @Test
  public void FlujoSoidata() throws InterruptedException{
	  pagina.InicioSesion();
	  incluirexcluir.IncluirExcluirIndividual(); 
	  consultaindividual.ConsultaIndividual();

	  
  }


  @AfterTest
  public void afterTest() {
	  driver.quit();
  }

}
