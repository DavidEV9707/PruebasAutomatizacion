package ConsultaMasiva;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectMasiva extends ClaseBase{
	public MapObjectMasiva (WebDriver driver) {
		super(driver);
	}
protected By btnconsulta= By.xpath("//*[@id=\"navbar\"]/ul/li[2]/a");
protected By lbltitulo= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[1]/h1");
protected By btnnatyjur= By.xpath("//*[@id=\"navbar\"]/ul/li[2]/ul/li[1]/a");
protected By btnmasiva= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[1]/div[2]/div/label[2]");
protected By lblmesconsulta= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[2]/div/div/div/div[2]/input");
protected By lblnombreconsulta= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[3]/div[2]/div[1]/input");
protected By btnarchivo= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/label");
protected By btnarchivo1= By.id("file-1");
protected By btnconsultamasiva= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[3]/div/button");
protected By btndescargaarchivo= By.xpath("/html/body/div[1]/div/div[1]/div/div/div[2]/div/div/div[4]/div/div[2]/div/table/tbody/tr[1]/td[9]/a");
protected By btnaceptar= By.xpath("//*[@id=\"q-portal--dialog--1\"]/div/div[2]/div/div[2]/div/button[2]");


protected String filePath = System.getProperty("user.dir") + "./src/test/resources/Archivos/identificaciones_personas_qa.csv";

}
