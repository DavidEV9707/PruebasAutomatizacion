package ConsultaMasiva;

import org.openqa.selenium.WebDriver;


public class PabObjectMasiva extends MapObjectMasiva{
	public PabObjectMasiva(WebDriver driver) {
		super(driver);
	}
	
	public void CargueMasivoConsulta()throws InterruptedException {
		Click(btnconsulta);
		Click(btnnatyjur);
		Click(btnmasiva);
		EnviarParametros(lblmesconsulta,"18");
		EnviarParametros(lblnombreconsulta,"ConsultaQA");
		/*Click(btnarchivo);*/
		EnviarParametros(btnarchivo1,filePath);
		Click(btnconsultamasiva);
		

		/*	ScrollDown();
		Click(btndescargaarchivo);
		Click(btnaceptar);
		*/
	}

}
