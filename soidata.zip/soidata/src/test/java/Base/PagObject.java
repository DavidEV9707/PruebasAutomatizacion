package Base;

import org.openqa.selenium.WebDriver;

public class PagObject extends MapObjetct{
	public PagObject(WebDriver driver) {
		super(driver);
	}
	
	public void urlSOIDATA(String url) {
		driver.get(url);
	}
	public void InicioSesion() throws InterruptedException{
		EnviarParametros(lblentidad,"ach");
		EnviarParametros(lblusuario,"asrodriguez@achcolombia.com.co");
		EnviarParametros(lblpass,"Marzo.2024+ach**");
		Click(btninicio);
		
	}

}
