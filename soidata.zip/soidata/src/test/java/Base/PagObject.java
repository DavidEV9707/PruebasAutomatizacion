package Base;


import org.openqa.selenium.WebDriver;

public class PagObject extends MapObjetct{
	public PagObject(WebDriver driver) {
		super(driver);
	}
	
	public void urlSOIDATA(String url) {
		driver.get(url);
	}
	public void InicioSesion() throws InterruptedException{
		EnviarParametros(lblentidad,"ach");
		EnviarParametros(lblusuario,"dbeltran@achcolombia.com.co");
		EnviarParametros(lblpass,"Marzo.2023+ach*");
		Click(btninicio);
		
	}

}
