package Base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MapObjetct extends ClaseBase{
	public MapObjetct(WebDriver driver) {
		super(driver);
	}	
protected By lblentidad= By.xpath("//input[@placeholder=\"Entidad\"]");
protected By lblusuario= By.xpath("//input[@placeholder=\"Usuario\"]");
protected By lblpass= By.xpath("//input[@placeholder=\"Contraseña\"]");
protected By btninicio= By.xpath("//div/button[@class=\"btn-login\"]");

}
