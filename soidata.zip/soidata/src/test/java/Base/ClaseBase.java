package Base;




import java.util.ArrayList;
import java.util.NoSuchElementException;
/*import java.util.concurrent.TimeUnit; */

import org.openqa.selenium.By;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
/*import org.openqa.selenium.WebDriver.Timeouts; */
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;


import org.openqa.selenium.JavascriptExecutor;



public class ClaseBase {
	public ClaseBase(WebDriver driver) {
		super();
	}
	protected static WebDriver driver;
	
	public static WebDriver ChromeConnection() {
		ChromeOptions chromeoptions = new ChromeOptions();
		chromeoptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		return driver;
	}
	
	public void TiempoEsperado(long tiempo) throws InterruptedException {
		Thread.sleep(tiempo);
		
	}
	public void Clickdescarga(By locator) throws InterruptedException{
		driver.findElement(locator).click();
		TiempoEsperado(3000);
	}
	public void Click(By locator) throws InterruptedException{
		driver.findElement(locator).click();
		TiempoEsperado(2000);
	}
	public void EnviarParametros(By locator, String palabra) throws InterruptedException{
		driver.findElement(locator).sendKeys(palabra);
		TiempoEsperado(2000);
	}
	public void limpiar(By locator) throws InterruptedException{
		driver.findElement(locator).clear();
		TiempoEsperado(1000);
	}
	public void Submit(By locator) throws InterruptedException{
		driver.findElement(locator).submit();
		TiempoEsperado(1000);
	}
	public Boolean ImagenDesplegada(By locator){
		try {
			return driver.findElement(locator).isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
		
	}
	public boolean ElementoSeleccionado(By locator) {
		try {
			return driver.findElement(locator).isSelected();
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	public boolean AsercionCorrecta(String textoesperado, By locator) {
		try {
		Assert.assertEquals(textoesperado, driver.findElement(locator).getText());
		} catch (NoSuchElementException e) {
			System.out.println("No se pudo validar la aserción porque no hubo coincidencia en los textos");
		}
		return false;
	}


public String textoesperado(By locator) {
	return driver.findElement(locator).getText();
}
public void Cleartexto(By locator) throws InterruptedException{
	driver.findElement(locator).clear();
	TiempoEsperado(1000);
}
public String ObtenerTitulo() throws InterruptedException{
	return driver.getTitle();
}
public WebElement ListaElementos(By locator) {
	return driver.findElement(locator);
}

public void ScrollDown() {
JavascriptExecutor js = (JavascriptExecutor) driver;
js.executeScript("window.scrollBy(0,350)", "");
}
public void CambioDePestañas() {
	ArrayList<String> CambioPestaña = new ArrayList<String>(driver.getWindowHandles());
	driver.switchTo().window(CambioPestaña.get(0));
}


/*public void EsperaImplicita() throws InterruptedException{
	Timeouts implicitlyWait = driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

*/
}