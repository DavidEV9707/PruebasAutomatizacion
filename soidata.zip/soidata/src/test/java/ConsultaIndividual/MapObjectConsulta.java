package ConsultaIndividual;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectConsulta extends ClaseBase{
	public MapObjectConsulta(WebDriver driver) {
		super(driver);
	}
	protected By ImagenACH= By.xpath("//div[@class='container']//div[@class='container']//div[@class='logoHeader']");
	protected By btnconsulta= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/a[1]");
	protected By btnconsulta1= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/ul[1]/li[1]/a[1]");
	protected By lbldocumento= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/input");
	protected By lblmesconsulta= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/input[1]");
	protected By btnconsultar= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[3]/div/button");
	protected By btnconsultajuridica= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div/label[2]");
	protected By listoptions= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/select[1]");
}
