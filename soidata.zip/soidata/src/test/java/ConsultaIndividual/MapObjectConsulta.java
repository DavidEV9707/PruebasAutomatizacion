package ConsultaIndividual;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectConsulta extends ClaseBase{
	public MapObjectConsulta(WebDriver driver) {
		super(driver);
	}
	protected By ImagenACH= By.xpath("//div[@class=\"logoHeader\"]");
	protected By btnconsulta= By.xpath("//a[contains(text(),'Consultas')]");
	protected By btnconsulta1= By.xpath("//li/a[contains(text(),'Detallada Natural y Jurídica')]");
	protected By lbldocumento= By.xpath("//input[@placeholder=\"Número\"]");
	protected By lblmesconsulta= By.xpath("//input[@placeholder=\"Periodo\"]");
	protected By btnconsultar= By.xpath("//button[contains(text(),'Consultar')]");
	protected By btnconsultajuridica= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div/label[2]");
	protected By listoptions= By.xpath("//select[@class=\"form-control\"]");
	protected By consultamasiva= By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div/div[1]/div[1]/div[2]/div/label[2]");
	protected By lblnombreConsulta= By.xpath("//input[contains(@placeholder,'Nombre de la consulta')]");
	protected By btnarchivo= By.id("file-1");
	protected By btndescarga= By.xpath("//td/a[contains(@class,'dow tooltips glyphicon glyphicon-download')]");
	protected By btnaceptardescarga= By.xpath("//div/button[contains(text(),'Aceptar')]");
	protected By btnnatural= By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div/label[1]");
	protected String FilePathPersona = System.getProperty("user.dir") + "./src/test/resources/Archivos/identificaciones_personas_qa.csv";
	
}
