package ConsultaIndividual;


import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.WebDriver;

public class PagObjectConsulta extends MapObjectConsulta{
	public PagObjectConsulta(WebDriver driver) {
		super(driver);
		
	}

	
	public void ConsultaIndividual() throws InterruptedException {
		Click(btnconsulta);
		Click(btnconsulta1);
		if(ImagenDesplegada(ImagenACH)) {
			EnviarParametros(lbldocumento,"1019024555");
			EnviarParametros(lblmesconsulta,"18");
			Click(btnconsultar);
			CambioDePestañas();
			Click(btnconsultajuridica);
			Select select = new Select(ListaElementos(listoptions));
			select.selectByValue("NI");
			EnviarParametros(lbldocumento,"282764927");
			EnviarParametros(lblmesconsulta,"18");
			Click(btnconsultar);
			CambioDePestañas();
		}
		else {
			System.out.println("No se encontró el elemento");
		}
	}


}
