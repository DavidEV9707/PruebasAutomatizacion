package ConsultaIndividual;


import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.WebDriver;

public class PagObjectConsulta extends MapObjectConsulta{
	public PagObjectConsulta(WebDriver driver) {
		super(driver);
		
	}

	
	public void ConsultaIndividual() throws InterruptedException {
		Click(btnconsulta);
		Click(btnconsulta1);
		if(ImagenDesplegada(ImagenACH)) {
			EnviarParametros(lbldocumento,"77554889");
			EnviarParametros(lblmesconsulta,"18");
			Click(btnconsultar);
			CambioDePestañas();
			Click(btnconsultajuridica);
			Listajuridica("NI");
			EnviarParametros(lbldocumento,"282764927");
			EnviarParametros(lblmesconsulta,"18");
			Click(btnconsultar);
			CambioDePestañas();
			Click(consultamasiva);
			Click(btnnatural);
			EnviarParametros(lblnombreConsulta,"PruebaQA");
			EnviarParametros(btnarchivo,FilePathPersona);
			Click(btnconsultar);
			TiempoEsperado(5000);
			Click(btndescarga);
			TiempoEsperado(3500);
			Click(btnaceptardescarga);
			
		}
		else {
			System.out.println("No se encontró el elemento");
		}
	}

public void Listajuridica(String palabra) {
	Select select = new Select(ListaElementos(listoptions));
	select.selectByValue(palabra);
}
public void TiempoEsperado(long tiempo) throws InterruptedException{
	Thread.sleep(tiempo);
}

}
