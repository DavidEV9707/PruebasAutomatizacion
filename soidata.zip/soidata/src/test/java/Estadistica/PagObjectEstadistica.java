package Estadistica;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PagObjectEstadistica extends MapObjectEstadistica{
	public PagObjectEstadistica(WebDriver driver) {
		super(driver);
		
	}

public void DescargaEntidades()throws InterruptedException {
	Click(btnestadistica);
	Click(btncalendar1);
	Click(fecha1);
	Click(btncalendar2);
	Click(fecha2);
	Select select = new Select(ListaElementos(entidades));
	select.selectByValue("pit");
	Click(btndescargar);
	EsperaDescarga(2500);
	select.selectByValue("ach");
	Click(btndescargar);
	EsperaDescarga(2500);
/*	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS); */
	select.selectByValue("Todas");
	Click(btndescargar); 
	EsperaDescarga(2500);
	Click(btnpdf);
	Click(btncalendar1);
	Click(fecha1);
	Click(btncalendar2);
	Click(fecha2);
	select.selectByValue("pit");
	Click(btndescargar);
	CambioDePestañas();
	select.selectByValue("ach");
	Click(btndescargar);
	CambioDePestañas();
	

	
	
}
public void EsperaDescarga(long tiempo) throws InterruptedException{
	Thread.sleep(tiempo);
}

}
