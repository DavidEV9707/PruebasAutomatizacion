package Estadistica;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PagObjectEstadistica extends MapObjectEstadistica{
	public PagObjectEstadistica(WebDriver driver) {
		super(driver);
		
	}

public void DescargaEntidades()throws InterruptedException {
	Click(btnestadistica);
	Click(btncalendar1);
	Click(fecha1);
	Click(btncalendar2);
	Click(fecha2);
	ListaEntidades("pit");
	Click(btndescargar);
	EsperaDescarga(2500);
	ListaEntidades("ach");
	Click(btndescargar);
	EsperaDescarga(2500);
/*	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS); */
	ListaEntidades("Todas");
	Click(btndescargar); 
	EsperaDescarga(2500);
	Click(btnpdf);
	EsperaDescarga(2500);
	Click(btncalendar1);
	Click(fecha1);
	Click(btncalendar2);
	Click(fecha2);
	ListaEntidades("pit");
	Click(btndescargar);
	CambioDePestañas();
	ListaEntidades("ach");
	Click(btndescargar);
	CambioDePestañas();
	

	
	
}
public void EsperaDescarga(long tiempo) throws InterruptedException{
	Thread.sleep(tiempo);
}
public void ListaEntidades(String palabra) throws InterruptedException{
	Select select = new Select(ListaElementos(entidades));
	select.selectByValue(palabra);
}
}