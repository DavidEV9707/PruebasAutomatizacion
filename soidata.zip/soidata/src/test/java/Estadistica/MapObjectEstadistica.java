package Estadistica;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectEstadistica extends ClaseBase{
	public MapObjectEstadistica(WebDriver driver) {
		super(driver);
	}
protected By btnestadistica= By.xpath("//li/a[contains(text(),'Estadísticas')]");
protected By btncalendar1= By.xpath("//input[@placeholder=\"Ingrese fecha inicial\"]");
protected By fecha1= By.xpath("//span[contains(text(),'1')]");
protected By btncalendar2= By.xpath("//input[@placeholder=\"Ingrese fecha final\"]");
protected By fecha2= By.xpath("//span[contains(text(),'13')]");
protected By entidades= By.xpath("//select[@class=\"form-control\"]");
protected By btndescargar= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/form/div[2]/div/div/button");
protected By btnpdf= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[4]/div[2]/div[1]/label[2]");
}


