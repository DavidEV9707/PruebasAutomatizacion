package IncluirExcluir;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import org.openqa.selenium.support.ui.Select;

public class PagObjectIncluirExcluir extends MapObjectIncluirExcluir{
	public PagObjectIncluirExcluir (WebDriver driver) {
		super(driver);
	}

	public void IncluirExcluirIndividual() throws InterruptedException{
		
		Click(btnusodatos);
		EnviarParametros(lbldocumento,"77554889");
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoexcluiresperado, textoesperado(textmessage));
		Click(btnincluir);
		Cleartexto(lbldocumento);
		EnviarParametros(lbldocumento,"77554889");
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoincluiresperado, textoesperado(textmessage));
		Click(btnexcluir);
		Click(btnjuridico);
		Select select = new Select(ListaElementos(listoptions));
		select.selectByValue("NI");
		EnviarParametros(lbldocumento,"282764927");
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoexcluiresperado, textoesperado(textmessage));
		Click(btnincluir);
		Cleartexto(lbldocumento);
		EnviarParametros(lbldocumento,"282764927");
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoincluiresperado, textoesperado(textmessage));
		Click(btnexcluir);
		Click(btnmasivo);
		Click(btnnatural);
		EnviarParametros(nameconsulta,"PruebaQA");
		EnviarParametros(btnmasivo1,FilePathPersona);
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoexcluirmasivo, textoesperado(textmessage));
		Click(btnincluir);
		Click(btnindividual);
		Click(btnmasivo);
		Click(btnnatural);
		EnviarParametros(nameconsulta,"PruebaQA");
		EnviarParametros(btnmasivo1,FilePathPersona);
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoincluirmasivo, textoesperado(textmessage));
		Click(btnexcluir);
		Click(btnmasivo);
		Click(btnjuridico);
		EnviarParametros(nameconsulta,"PruebaQA");
		EnviarParametros(btnmasivo1,FilePathEmpresa);
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoexcluirmasivo, textoesperado(textmessage));
		Click(btnincluir);
		Click(btnindividual);
		Click(btnmasivo);
		Click(btnjuridico);
		EnviarParametros(nameconsulta,"PruebaQA");
		EnviarParametros(btnmasivo1,FilePathEmpresa);
		EnviarParametros(lblcorreo,"davidespejo@cbit-online.com");
		Click(btnguardar);
		Assert.assertEquals(textoincluirmasivo, textoesperado(textmessage));
		
}

}
