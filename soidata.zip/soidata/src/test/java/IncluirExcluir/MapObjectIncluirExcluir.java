package IncluirExcluir;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectIncluirExcluir extends ClaseBase{
	public MapObjectIncluirExcluir(WebDriver driver) {
		super(driver);
	}
	/*Elementos web*/
	protected By btnusodatos= By.xpath("//a[text()='Uso de Datos']");
	protected By lbldocumento= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[4]/div[2]/div[2]/input");
	protected By lblcorreo= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[2]/div/div/div/input");
	protected By btnguardar= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[3]/div/button");
	protected By textmessage= By.xpath("/html[1]/body[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]");
	protected By btnincluir= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[1]/div[2]/div/label[2]");
	protected By textpositivemessage= By.xpath("/div/div/div/div");
	protected By btnexcluir= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[1]/div[2]/div/label[1]");
	protected By btnmasivo= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div/label[2]");
	protected By nameconsulta= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[4]/div[2]/div[1]/input");
	protected By btnmasivo1= By.id("file-1");
	protected By btnnatural= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[3]/div[2]/div/label[1]");
	protected By btnjuridico= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[3]/div[2]/div/label[2]");
	protected By listoptions= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[4]/div[2]/div[1]/select[1]");
	protected By btnindividual= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div/label[1]");
	/* Cuadros de textos actuales*/
	protected String textoexcluiresperado= "Esta identificación se ha excluido de las consultas";
	protected String textoincluiresperado= "Esta identificación se ha incluido en las consultas";
	protected String textoexcluirmasivo= "Las identificaciones se han excluido de las consultas";
	protected String textoincluirmasivo="Las identificaciones se han incluidos en las consultas";
	protected String FilePathPersona = System.getProperty("user.dir") + "./src/test/resources/Archivos/personas 67.csv";
	protected String FilePathEmpresa = System.getProperty("user.dir") + "./src/test/resources/Archivos/empresas.csv";
	
}
