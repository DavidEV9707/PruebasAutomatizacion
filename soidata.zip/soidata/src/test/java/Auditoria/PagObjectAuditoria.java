package Auditoria;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PagObjectAuditoria extends MapObjectAuditoria{

	public PagObjectAuditoria(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void DescargaAuditoria() throws InterruptedException{
		Click(btnauditoria);
		SeleccionarComponente("Migracion");
		Seleccionarobjeto("Proceso_migracion");
		Seleccionaraccion("Iniciar");
		Click(FechaInicial);
		Click(DiaInicial);
		Click(Fechafinal);
		Click(DiaFinal);
		Click(btndescarga);
		TiempoDeEspera(2500);
		Seleccionaraccion("Detener");
		Click(FechaInicial);
		Click(DiaInicial);
		Click(Fechafinal);
		Click(DiaFinal);
		Click(btndescarga);
		TiempoDeEspera(2500);	
	}
	
	public void SeleccionarComponente(String palabra) {
		Select selectcomponent = new Select(ListaElementos(ListaComponente));
		selectcomponent.selectByValue(palabra);
	}
	public void Seleccionarobjeto(String palabra) {
		Select selectobjeto= new Select(ListaElementos(ListaObjeto));
		selectobjeto.selectByValue(palabra);
	}
	public void Seleccionaraccion(String palabra) {
		Select selectaccion= new Select(ListaElementos(ListaAcciones));
		selectaccion.selectByValue(palabra);
	}
	public void TiempoDeEspera(long tiempo) throws InterruptedException{
		Thread.sleep(tiempo);
	}

}
