package Auditoria;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectAuditoria extends ClaseBase{

	public MapObjectAuditoria(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	protected By btnauditoria= By.xpath("//li/a[contains(text(),'Auditoría')]");
	protected By ListaComponente= By.xpath("//select/option[contains(text(),'Seleccione un componente')]");
	protected By ListaObjeto= By.xpath("//select/option[contains(text(),'Seleccione un objeto')]");
	protected By ListaAcciones= By.xpath("//select/option[contains(text(),'Seleccione una acción')]");
	protected By FechaInicial= By.xpath("//input[@placeholder=\"Ingrese fecha inicial\"]");
	protected By DiaInicial= By.xpath("//span[contains(text(),'1')]");
	protected By Fechafinal= By.xpath("//input[@placeholder=\"Ingrese fecha final\"]");
	protected By DiaFinal= By.xpath("//span[contains(text(),'17')]");
	protected By btndescarga= By.xpath("//button[@type=\"submit\"]");
}
