package ConsultaConsolidadaJuridica;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.openqa.selenium.support.ui.Select;


public class PagObjectConsultaConsolidadaJuridica extends MapObjectConsultaConsolidadaJuridica{
public PagObjectConsultaConsolidadaJuridica(WebDriver driver) {
	super(driver);
}
public void ConsultaIndividualMasivaJuridica() throws InterruptedException{
	Click(btnconsulta);
	Click(btnconsultajuridica);
	Assert.assertEquals(titulo, textoesperado(currentittle));
	Select select = new Select(ListaElementos(btnNIT));
	select.selectByValue("NI");
	EnviarParametros(lblNIT,"890311953");
	EnviarParametros(lblprimervalor,"200");
	EnviarParametros(lblsegundovalor,"32000000");
	Click(btnconsultadocumento);
	CambioDePestañas();
	Click(btnmasiva);
	EnviarParametros(lblnombreconsulta,"ValidacionQA");
	Click(limpiezadatos);
	EnviarParametros(lblprimervalor,"200");
	EnviarParametros(lblsegundovalor,"32000000");
	EnviarParametros(btncarguearchivo,filepathjuridica);
	Click(btnconsultadocumento);
	Clickdescarga(btndescargaarchivo);
	Click(btnaceptardescarga);
	
}
}
