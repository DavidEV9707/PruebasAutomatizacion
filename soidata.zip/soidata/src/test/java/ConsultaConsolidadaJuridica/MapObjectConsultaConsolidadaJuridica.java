package ConsultaConsolidadaJuridica;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectConsultaConsolidadaJuridica extends ClaseBase{
	public MapObjectConsultaConsolidadaJuridica(WebDriver driver) {
		super(driver);
	}
	protected By btnconsulta= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/a[1]");
	protected By btnconsultajuridica= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/ul[1]/li[3]/a[1]");
	protected By currentittle= By.xpath("//h1[contains(text(),'CONSOLIDADA PERSONA JURÍDICA')]");
	protected By btnNIT= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/select[1]");
	protected By lblprimervalor= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[2]/input[1]");
	protected By lblsegundovalor= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/div[2]/input[1]");
	protected By lblNIT= By.xpath("//input[@placeholder=\"Número\"]");
	protected By btnconsultadocumento= By.xpath("//div/button[contains(text(),'Consultar')]");
	protected By btnmasiva= By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/label[2]");
	protected By btndescargaarchivo= By.xpath("//td/a[@class=\"dow tooltips glyphicon glyphicon-download\"]");
	protected By lblnombreconsulta= By.xpath("//input[@placeholder=\"Nombre de la consulta\"]");
	protected By btncarguearchivo= By.id("file-1");
	protected By limpiezadatos= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[2]/div[1]/span");
	protected By btnaceptardescarga= By.xpath("//div/button[contains(text(),'Aceptar')]");
	protected String titulo= "CONSOLIDADA PERSONA JURÍDICA";
	protected String filepathjuridica= System.getProperty("user.dir") + "./src/test/resources/Archivos/identificaciones_empresas_qa.csv";
}
