package ConsultaConsolidadaNatural;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import java.util.ArrayList;

public class PagObjectConsultaDetallada extends MapObjectConsultaDetallada{
	public PagObjectConsultaDetallada(WebDriver driver) {
		super(driver);
	}

	public void ConsultaConsolidada()throws InterruptedException {
		Click(btnconsulta);
		Click(btnconsultaconsolidada);
		Assert.assertEquals(textoconsultaconsolidada, textoesperado(currenttitle));
		/*Click(btnindividual);*/
		EnviarParametros(lbldocumento,"77554889");
		EnviarParametros(lblperiodo,"36");
		Click(btnconsultaperiodo);
		ArrayList<String> CambioPestaña= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(CambioPestaña.get(0));
		Click(btnmasiva);
		EnviarParametros(lblnombreconsulta,"PersonasQA");
		EnviarParametros(btncarguearchivo,filepathpersona);
		EnviarParametros(lblperiodo,"36");
		Click(btnconsultaperiodo);
		Click(btndescarga);
		Click(btnaceptardescarga);
		
		
		
		
	}

}
