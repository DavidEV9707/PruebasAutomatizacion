package ConsultaConsolidadaNatural;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.ClaseBase;

public class MapObjectConsultaDetallada extends ClaseBase{
	public MapObjectConsultaDetallada (WebDriver driver) {
		super(driver);
	}
	protected By btnconsulta= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/a[1]");
	protected By btnconsultaconsolidada= By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/nav[1]/div[1]/nav[1]/div[1]/div[2]/ul[1]/li[2]/ul[1]/li[2]/a[1]");
	protected By currenttitle= By.xpath("//div/h1[contains(text(),'CONSULTAS CONSOLIDADAS PERSONA NATURAL')]");
	protected By btnindividual= By.xpath("//div/label/input[@value=\"Individual\"]");
	protected By btnmasiva= By.xpath("//*[@id=\"mainLayout\"]/div/div/div[2]/div/div/div[1]/div[1]/div[2]/div/label[2]");
	protected By lbldocumento= By.xpath("//div/input[@placeholder=\"Número\"]");
	protected By lblperiodo= By.xpath("//div/input[@placeholder=\"Periodo\"]");
	protected By btnconsultaperiodo= By.xpath("//div/button[@class=\"btn btn-primary\"]");
	protected By lblnombreconsulta= By.xpath("//input[@placeholder=\"Nombre de la consulta\"]");
	protected By btncarguearchivo= By.id("file-1");
	protected By btndescarga= By.xpath("//td/a[@class=\"dow tooltips glyphicon glyphicon-download\"]");
	protected By btnaceptardescarga= By.xpath("//div/button[contains(text(),'Aceptar')]");
	
	protected String filepathpersona= System.getProperty("user.dir") + "./src/test/resources/Archivos/identificaciones_personas_qa.csv";
	protected String textoconsultaconsolidada= "CONSULTAS CONSOLIDADAS PERSONA NATURAL";
	
	
	

}
